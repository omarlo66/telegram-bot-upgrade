from datetime import date


def format_date(d: date):
    return d.strftime('%d/%m/%Y')
