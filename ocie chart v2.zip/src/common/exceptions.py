class EmployeeAlreadyExists(Exception):
    ...


class SubgroupAlreadyExists(Exception):
    ...


class SubgroupIsMainGroup(Exception):
    ...


class UserNotFound(Exception):
    ...
