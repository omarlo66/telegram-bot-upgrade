from src.common.settings import * # noqa
